def display_pattern(n):
    for i in range(1, n + 1):
        print((str(i) + " ") * i)

display_pattern(10)
